from flask import Flask, request, jsonify
from joblib import load
from flask_cors import CORS
import numpy as np
import spacy
import re

# Load SpaCy model
nlp = spacy.load("en_core_web_sm")

# Load the trained pipeline
pipeline = load('task_duration_model.joblib')

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Define the route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    task_name = data['task_name']
    task_description = data['task_description']
    
    # Combine task name and description
    new_task_text = task_name + ' ' + task_description
    
    # Extract features using the same transformer as during training
    class TextFeatureExtractor:
        def transform(self, X):
            num_tokens = []
            max_token_length = []
            min_token_length = []
            avg_token_length = []
            num_stopwords = []
            fraction_stopwords = []
            num_entities = []
            num_names = []
            has_phone_number = []
            num_action_words = []
            num_depth_words = []
            num_pos_tags = []

            for text in X:
                doc = nlp(text)
                tokens = [token.text for token in doc]
                num_tokens.append(len(tokens))
                token_lengths = [len(token) for token in tokens]
                max_token_length.append(max(token_lengths))
                min_token_length.append(min(token_lengths))
                avg_token_length.append(np.mean(token_lengths))
                num_stopwords.append(sum(1 for token in doc if token.is_stop))
                fraction_stopwords.append(sum(1 for token in doc if token.is_stop) / len(tokens))
                num_entities.append(len(doc.ents))
                num_names.append(sum(1 for ent in doc.ents if ent.label_ == "PERSON"))
                has_phone_number.append(bool(re.search(r'\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}', text)))
                num_action_words.append(len([token.text.lower() for token in doc if token.pos_ == 'VERB']))
                num_depth_words.append(len([token.text.lower() for token in doc if token.text.lower() in ['deep', 'detailed', 'careful', 'thorough', 'overview', 'lightweight', 'light', 'end to end', 'e2e']]))
                num_pos_tags.append(len(set([token.pos_ for token in doc])))

            num_tokens = np.array(num_tokens).reshape(-1, 1)
            max_token_length = np.array(max_token_length).reshape(-1, 1)
            min_token_length = np.array(min_token_length).reshape(-1, 1)
            avg_token_length = np.array(avg_token_length).reshape(-1, 1)
            num_stopwords = np.array(num_stopwords).reshape(-1, 1)
            fraction_stopwords = np.array(fraction_stopwords).reshape(-1, 1)
            num_entities = np.array(num_entities).reshape(-1, 1)
            num_names = np.array(num_names).reshape(-1, 1)
            has_phone_number = np.array(has_phone_number).reshape(-1, 1)
            num_action_words = np.array(num_action_words).reshape(-1, 1)
            num_depth_words = np.array(num_depth_words).reshape(-1, 1)
            num_pos_tags = np.array(num_pos_tags).reshape(-1, 1)

            features = np.concatenate((num_tokens, max_token_length, min_token_length, avg_token_length,
                                       num_stopwords, fraction_stopwords, num_entities, num_names,
                                       has_phone_number, num_action_words, num_depth_words, num_pos_tags), axis=1)
            return features

    # Instantiate the feature extractor
    text_feature_extractor = TextFeatureExtractor()

    # Transform the input text
    new_task_features = text_feature_extractor.transform([new_task_text])

    # Predict the duration using the loaded pipeline
    predicted_duration = pipeline.predict(new_task_features)

    # Return the result as JSON
    return jsonify({'duration': predicted_duration[0]})

if __name__ == '__main__':
    app.run(debug=True)
