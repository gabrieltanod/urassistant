// <!-- SCRIPT TO SAVE / LOAD REMINDERS -->
window.addEventListener("DOMContentLoaded", () => {
  const todayReminders =
    JSON.parse(localStorage.getItem("todayReminders")) || [];
  const scheduledReminders =
    JSON.parse(localStorage.getItem("scheduledReminders")) || [];

  // Render reminders to the appropriate list elements
  renderReminders(todayReminders, "today-reminders");
  renderReminders(scheduledReminders, "scheduled-reminders");
});

// Function to render reminders to the specified list element
function renderReminders(reminders, listId) {
  const list = document.getElementById(listId);
  list.innerHTML = ""; // Clear existing list items

  reminders.forEach((reminder) => {
    const listItem = document.createElement("li");
    listItem.textContent =
      reminder.title + (reminder.date ? " - " + reminder.date : "");
    list.appendChild(listItem);
  });
}

// Function to add a new reminder
function addReminder() {
  const title = document.getElementById("reminder-title").value;
  const date = document.getElementById("reminder-date").value;
  const reminder = { title, date };

  // Determine which list to add the reminder to
  const listId = date ? "scheduled-reminders" : "today-reminders";
  const reminders = JSON.parse(localStorage.getItem(listId)) || [];
  reminders.push(reminder);

  // Save updated reminders to local storage
  localStorage.setItem(listId, JSON.stringify(reminders));

  // Render the updated list of reminders
  renderReminders(reminders, listId);

  // Reset form fields
  document.getElementById("reminder-title").value = "";
  document.getElementById("reminder-date").value = "";
}

// <!-- SIDE BAR -->
const hamBurger = document.querySelector(".toggle-btn");

hamBurger.addEventListener("click", function () {
  document.querySelector("#sidebar").classList.toggle("expand");
});

/* script.js */
function openTab(evt, tabName) {
  const tabContents = document.querySelectorAll(".tab-content");
  const tabLinks = document.querySelectorAll(".tab-link");

  tabContents.forEach((content) => (content.style.display = "none"));
  tabLinks.forEach((link) => link.classList.remove("active"));

  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.classList.add("active");
}

function showAddReminderForm() {
  document.getElementById("add-reminder-form").style.display = "block";
}

function navigateToCalendar() {
  window.location.href = "calendar.html";
}

function addReminder() {
  const title = document.getElementById("reminder-title").value;
  const date = document.getElementById("reminder-date").value;
  const reminder = { title, date };

  // Add reminder to appropriate list
  if (!date) {
    addReminderToList("all-reminders", reminder);
  } else if (new Date(date).toDateString() === new Date().toDateString()) {
    addReminderToList("today-reminders", reminder);
    addReminderToList("main-today-reminders", reminder);
  } else {
    addReminderToList("scheduled-reminders", reminder);
  }

  // Reset form
  document.getElementById("reminder-title").value = "";
  document.getElementById("reminder-date").value = "";
  document.getElementById("add-reminder-form").style.display = "none";
}

function addReminderToList(listId, reminder) {
  const list = document.getElementById(listId);
  const listItem = document.createElement("li");
  listItem.textContent = `${reminder.title} ${
    reminder.date ? "- " + reminder.date : ""
  }`;
  list.appendChild(listItem);
}

// Initialize with the first tab open
document.addEventListener("DOMContentLoaded", () => {
  document.querySelector(".tab-link").click();
});
